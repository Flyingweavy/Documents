package pack1;

public class base {
	public int a=1;
	protected int b=2;
	private int c=3;
	int d=4;
	public
	base()
	{System.out.println("\nin the base class");
		System.out.println("the public member is"+a);
		System.out.println("the private member is"+c);
		System.out.println("the protected member is"+b);
		System.out.println("the default member is"+d);
	}

}

