package pack1;

public class project1 {

	public static void main(String[] args) {
		base b=new base();
		sub1 a=new sub1();
		other c=new other();
            pack2.other2 d=new pack2.other2();
           pack2.sub2 e=new pack2.sub2();
	}

}

