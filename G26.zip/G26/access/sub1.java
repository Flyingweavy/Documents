package pack1;

public class sub1 extends base {
	sub1()
	{System.out.println("\nin the sub1 class ");
		System.out.println("the public member is"+a);
		//System.out.println("the private member is"+c);
		System.out.println("the protected member is"+b);
		System.out.println("the default member is"+d);
	}

}

