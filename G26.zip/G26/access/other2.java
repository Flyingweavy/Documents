package pack2;
import pack1.*;
public class other2 {
base obj=new base();
public
other2()
{
	System.out.println("\nin the other2 class of pack 2");
	System.out.println("the public member is"+obj.a);
	//System.out.println("the private member is"+c);
	//System.out.println("the protected member is"+obj.b);
	//System.out.println("the default member is"+obj.d);
}
}

